
Your job is to work on these two files:
 - Percolation.java
 - PercolationStats.java

Nothing to do in these three files:
 - WeightedQuickUnionUF.java
 - PercolationVisualizer.java
 - StdDraw.java
